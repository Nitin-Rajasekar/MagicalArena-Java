package com.magicalarena.dice;

public interface Die {
    int roll();
}

